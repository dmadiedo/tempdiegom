if ($null -eq $uri -or $null -eq $dest -or $null -eq $taskname -or $null -eq $username -or $null -eq $password) {
   throw "Missing parameters"
}
if (-not (Test-Path -Path $dest -PathType Leaf)) {
   Invoke-WebRequest -Uri $uri -OutFile $dest
}
$task = Get-ScheduledTask -TaskName $taskname -TaskPath '\' -ErrorAction SilentlyContinue
if ($task -eq $null) {
   $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-File $dest"
   $task = Register-ScheduledTask -TaskName $taskname -Action $action -User $username -Password $password
}
$task | Start-ScheduledTask
do {
   $task = Get-ScheduledTask -TaskName $taskname -TaskPath '\'
   Start-Sleep -Seconds 1
} while ($task.State -eq 'Running')
$TaskInfo = Get-ScheduledTaskInfo -InputObject $task
$task | Unregister-ScheduledTask -Confirm:$False
Remove-Item -Path $dest
if ($TaskInfo.LastTaskResult -ne 0) {
   throw "There was an error running the script"
}
