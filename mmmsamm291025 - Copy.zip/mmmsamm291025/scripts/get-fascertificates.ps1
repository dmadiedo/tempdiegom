param(
        [switch]$Install,
        [switch]$Uninstall,
        [string]$InstallPath = "C:\SamanaStore\fascerts",
        [string]$ShareName = "FasCerts",
        [string]$TaskName = "Samm-Fas-Certs"
)

Add-PSSnapin Citrix.A*

$CitrixFasAddress=(Get-FasServer)[0].Address
$CurrentCertificate=Get-FasAuthorizationCertificate -FullCertInfo
if ($CurrentCertificate -eq $null) {
	exit 1
}
$file = Join-Path -Path $InstallPath -ChildPath "fascerts.json"
$data=@{
        FasAddress=$CitrixFasAddress
        CurrentDate=(get-Date -Format o)
        CitrixFasAddress=$CitrixFasAddress
        DefaultCA=(Get-FasMsCertificateAuthority -Default)
        CurrentCertificate=$CurrentCertificate
        DaysToExpire=($CurrentCertificate.ExpiryDate - (Get-Date)).Days
}
ConvertTo-Json -InputObject $data | Out-File -FilePath $file
