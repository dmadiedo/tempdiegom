$taskname="test123"
$user='mmmhc\\citrixservices2'
$password='eUwjnp2NxJvDrG4Eqkqo'
$scriptname='get-fascertificates.ps1'
$scriptpath='c:\\SamanaStore\\'
$b64script='cGFyYW0oCiAgICAgICAgW3N3aXRjaF0kSW5zdGFsbCwKICAgICAgICBbc3dpdGNo'+
    'XSRVbmluc3RhbGwsCiAgICAgICAgW3N0cmluZ10kSW5zdGFsbFBhdGggPSAiQzpc'+
    'U2FtYW5hU3RvcmVcZmFzY2VydHMiLAogICAgICAgIFtzdHJpbmddJFNoYXJlTmFt'+
    'ZSA9ICJGYXNDZXJ0cyIsCiAgICAgICAgW3N0cmluZ10kVGFza05hbWUgPSAiU2Ft'+
    'bS1GYXMtQ2VydHMiCikKCkFkZC1QU1NuYXBpbiBDaXRyaXguQSoKCiRDaXRyaXhG'+
    'YXNBZGRyZXNzPShHZXQtRmFzU2VydmVyKVswXS5BZGRyZXNzCiRDdXJyZW50Q2Vy'+
    'dGlmaWNhdGU9R2V0LUZhc0F1dGhvcml6YXRpb25DZXJ0aWZpY2F0ZSAtRnVsbENl'+
    'cnRJbmZvCiRmaWxlID0gSm9pbi1QYXRoIC1QYXRoICRJbnN0YWxsUGF0aCAtQ2hp'+
    'bGRQYXRoICJmYXNjZXJ0cy5qc29uIgokZGF0YT1AewogICAgICAgIEZhc0FkZHJl'+
    'c3M9JENpdHJpeEZhc0FkZHJlc3MKICAgICAgICBDdXJyZW50RGF0ZT0oZ2V0LURh'+
    'dGUgLUZvcm1hdCBvKQogICAgICAgIENpdHJpeEZhc0FkZHJlc3M9JENpdHJpeEZh'+
    'c0FkZHJlc3MKICAgICAgICBEZWZhdWx0Q0E9KEdldC1GYXNNc0NlcnRpZmljYXRl'+
    'QXV0aG9yaXR5IC1EZWZhdWx0KQogICAgICAgIEN1cnJlbnRDZXJ0aWZpY2F0ZT0k'+
    'Q3VycmVudENlcnRpZmljYXRlCiAgICAgICAgRGF5c1RvRXhwaXJlPSgkQ3VycmVu'+
    'dENlcnRpZmljYXRlLkV4cGlyeURhdGUgLSAoR2V0LURhdGUpKS5EYXlzCn0KQ29u'+
    'dmVydFRvLUpzb24gLUlucHV0T2JqZWN0ICRkYXRhIHwgT3V0LUZpbGUgLUZpbGVQ'+
    'YXRoICRmaWxlCgo='
$bytes = [System.Convert]::FromBase64String($b64script);
$script=Join-Path -Path $scriptpath -ChildPath $scriptname
[System.IO.File]::WriteAllBytes($script, $bytes)
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-File $($script)'
Register-ScheduledTask -TaskName $taskname -Action $action -User $user -Password $password
Start-ScheduledTask -TaskPath '\\' -TaskName $taskname

